menu_options = {
    1: 'Übung 1',
    2: 'Übung 2',
    3: 'Übung 3',
    4: 'Übung 4',
    5: 'Übung 5',
    6: 'Übung 6',
    7: 'Übung 7',
    8: 'Exit',
}


def print_menu():
    for key in menu_options.keys():
        print(key, '-->', menu_options[key])


def u1():
    lista = [23, 45, 53, 53, 95, 72, 97, 50, 44, 95]
    rez = []
    for i in range(0, len(lista) - 2):
        ct = 0
        for j in range(i + 1, len(lista) - 1):
            if lista[i] == lista[j]:
                ct += 1
        if ct == 0:
            rez.append(lista[i])
    print(rez)


def u2():
    lista = [24, 42, 67, 51, 88, 90, 88, 76, 37]
    ct = 0
    for i in range(0, len(lista) - 2):
        for j in range(i + 1, len(lista) - 1):
            aux = lista[j]
            inv = 0
            while aux > 0:
                inv = inv * 10 + aux % 10
                aux //= 10
            if inv == lista[i]:
                ct += 1
    print(ct)


def u3():
    lista = [23, 32, 45, 67, 21, 34, 89, 34, 76, 31]
    new = 0
    # lista.sort(reverse=True)
    for i in range(0, len(lista)):
        for j in range(i + 1, len(lista)):
            if lista[j] > lista[i]:
                aux = lista[i]
                lista[i] = lista[j]
                lista[j] = aux
    for i in range(0, len(lista)):
        new = new * 100 + lista[i]
    print(new)


def u4():
    lista = [4, 34, 56, 78, 36, 23]
    key = lista[0]
    new_list = []
    new_list.append(lista[0])
    for i in range(1, len(lista)):
        lista[i] = lista[i] * key
        new_list.append(lista[i])
    print(new_list)


def u5():
    # def operations(fs, a, b):
    #     if "*" in fs:
    #         res = a * b
    #     elif "/" in fs:
    #         res = a // b
    #     elif "-" in fs:
    #         res = a - b
    #     else:
    #         res = a + b
    #     return res
    def result_from_side_operation(formula_side, a, b):
        if "*" in formula_side:
            result = a * b
        elif "/" in formula_side:
            result = a // b
        elif "-" in formula_side:
            result = a - b
        else:
            result = a + b

        return result

    def filter_numbers(numbers_list, formula_string):
        filtered_numbers = []

        # Impart string formula in doua parti
        # ex: formula = "3*x=y/3" devine ["3*x", "y/3"]
        formula_sides = formula_string.split("=")

        # rjust umple cu 0 stringul daca are lungimea mai mica decat 3
        original_left_side = str(formula_sides[0])
        original_right_side = str(formula_sides[1])

        print(f"left side: {original_left_side}")
        print(f"right side: {original_right_side}")
        print(30 * "-")

        # Fac operatiile pentru toate numerele din lista
        for number in numbers_list:
            # pentru 31 va fi x = 3 y = 1
            x = number // 10
            y = number % 10

            # Aici se va reveni la formula originala
            # ex: "3*3" va redeveni 3*x in partea stanga
            # ex: "1/3" va redeveni "y/3" in partea dreapta
            left_side = original_left_side.rjust(3, "0")
            right_side = original_right_side.rjust(3, "0")

            # Inlocuiesc x si y din formula string cu valoarea lor
            # ex: "3*x" devine "3*3" cand numarul este 31
            if "x" in left_side:
                left_side = left_side.replace("x", str(x))
            else:
                right_side = left_side.replace("x", str(x))

            # ex "y/3" devine "1/3" cand numarul este 31
            if "y" in right_side:
                right_side = right_side.replace("y", str(y))
            else:
                left_side = left_side.replace("y", str(y))

            print(f"check: {left_side} = {right_side}")


             # Extrag valorile ca int din left_side si right_side

            left_first_value = int(left_side[0])

            left_second_value = int(left_side[2])

            right_first_value = int(right_side[0])

            right_second_value = int(right_side[2])

            # Salvez rezultatul operatiei facuta pe valorile extrase
            left_side_result = result_from_side_operation(left_side,
                                                            left_first_value,
                                                            left_second_value)

            right_side_result = result_from_side_operation(right_side,
                                                            right_first_value,
                                                            right_second_value)

            # Verific egalitatea cu valorile extrase din stringuri

            if left_side_result == right_side_result:

                filtered_numbers.append(number)

                print("true")
            else:
                print("false")


        print(30 * "-")
        print(f"filtered numbers: {filtered_numbers}")

    numbers = [31, 13, 93, 63, 19]

    # Formule pentru testare
    # formula = "x+2=y"
    # formula = "x=3*y"
    # formula = "x/y=2"
    # formula = "x-y=6"
    formula = "1=1"

    filter_numbers(numbers, formula)


def u6():
    lista = [345, 546, 674, 213, 498, 807, 716, 639, 971, 142, 465]
    temp = []
    rez = []

    def domino(a, b):
        while b > 9:
            b //= 10
        if a % 10 == b:
            return True
        return False

    for i in range(0, len(lista) - 1):
        if domino(lista[i], lista[i + 1]):
            temp.append(lista[i])
        else:
            if len(temp) > len(rez):
                temp.append(lista[i])
                rez = temp
                temp = []
    if len(temp) > len(rez):
        rez = temp
    print(rez)


def u7():
    lista = [19, 30, 59, 49, 24, 12, 34]

    def cmmdc(x, y):
        x = abs(x)
        y = abs(y)
        while x != y:
            if x > y:
                x -= y
            else:
                y -= x
        return x

    def cmmmc(x, y):
        return x * y // cmmdc(x, y)

    index1 = int(input("Indexul initial este: "))
    index2 = int(input("Indexul final este: "))

    for i in range(0, len(lista)):
        if index1 < 0 or index1 > len(lista) - 1 or index2 < 1 or index2 > len(lista):
            print("<>!ACHTUNG!<>Index out of range<>!ACHTUNG!<>")
            break
        else:
            k = lista[index1 + 1]
            for i in range(index1 + 1, index2):
                k = cmmmc(k, lista[i + 1])
            print(cmmmc(lista[index1], lista[index2]))
            break


if __name__ == '__main__':
    while True:
        print_menu()
        option = ''
        try:
            option = int(input('Enter your choice: '))
        except:
            print('Wrong input. Please enter a number ...')
        # Check what choice was entered and act accordingly
        if option == 1:
            u1()
        elif option == 2:
            u2()
        elif option == 3:
            u3()
        elif option == 4:
            u4()
        elif option == 5:
            u5()
        elif option == 6:
            u6()
        elif option == 7:
            u7()
        elif option == 8:
            print('Thanks message before exiting')
            exit()
        else:
            print('Invalid option. Please enter a number between 1 and 8.')

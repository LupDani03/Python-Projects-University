f = open('zeichnen.txt', 'r')
x = f.read()
l = x.split('d')
def rock():
    print(l[0])
    return 'rock'


def paper():
    print(l[1])
    return 'paper'


def scissors():
    print(l[2])
    return 'scissors'

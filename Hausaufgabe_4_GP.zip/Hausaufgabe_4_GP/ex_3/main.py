import art
from random import choice


def main(scor):
    print('1. Rock')
    print('2. Paper')
    print('3. Scissors')
    user_input = input('Choose a move: ')

    user = user_move(user_input)
    comp = comp_move()

    scor = compare(user, comp, scor)
    if scor[0] + scor[1] < 3:
        main(scor)
    elif scor[0] + scor[1] == 3:
        if scor[0] > scor[1]:
            print('You won')
        else:
            print('You lost')



def comp_move():
    moves = [art.rock, art.paper, art.scissors]
    return choice(moves)()


def user_move(user_input):
    if user_input == '1':
        user = art.rock()
    elif user_input == '2':
        user = art.paper()
    else:
        user = art.scissors()
    return user


def compare(user, comp, scor):
    print(f"Computer: {comp} | User: {user}")
    if user == comp:
        print('Round drawn')
    elif (
            user == 'rock' and comp == 'scissors' or
            user == 'scissors' and comp == 'paper' or
            user == 'paper' and comp == 'rock'
    ):
        print('Round won')
        scor = (scor[0] + 1, scor[1])
    else:
        print('Round lost')
        scor = (scor[0], scor[1] + 1)
    return scor


scor = (0, 0)
main(scor)

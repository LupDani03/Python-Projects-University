from ex_1.symbols import add_symbol
from ex_1.word_printing import define_word, draw_word

def print_options():
    print ('1. Draw a word')
    print ('2. Define a word')
    print ('3. Define a symbol')

def menu():
    print_options()
    user_input = int(input('Choose what you would like to do: '))
    while user_input <= 0 or user_input >= 4:
        print('Invalid selection')
        user_input = int(input('Choose what you would like to do: '))
    if user_input == 1:
        draw_word()
    elif user_input == 2:
        define_word()
    else:
        add_symbol()
menu()
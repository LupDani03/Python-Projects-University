import turtle
from ex_1.predef_symbols import symb_dict

def verify_if_symbol_exists(symbol):
    with open('custom_symbols.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip().split(" ")
            if line[0] == symbol or symbol in symb_dict:
                return True
        return False


def add_symbol():
    symbol = input('Define a symbol: ')
    t = turtle.Turtle()
    if verify_if_symbol_exists(symbol) is True:
        print('Symbol is already defined')
    else:
        print('Draw the symbol using W, A, S, D, F, G to control the pen')
        instructions = ''
        possible_outcome = ['W', 'A', 'S', 'D', 'F', 'G']
        symbol_creation = input('Control the pen: ')
        while symbol_creation in possible_outcome:
            if symbol_creation == 'W':
                t.forward(10)
                instructions += symbol_creation
            elif symbol_creation == 'S':
                t.backward(10)
                instructions += symbol_creation
            elif symbol_creation == 'D':
                t.right(45)
                instructions += symbol_creation
            elif symbol_creation == 'A':
                t.left(45)
                instructions += symbol_creation
            elif symbol_creation == 'F':
                t.up()
                instructions += symbol_creation
            elif symbol_creation == 'G':
                t.down()
                instructions += symbol_creation
            else:
                print('You have succesfully defined the symbol')
                break
            symbol_creation = input('Control the pen: ')
        turtle.bye()
        append_symbol(symbol, instructions)

def recreate_symbol(instructions, t):
    for step in instructions:
        if step == 'W':
            t.forward(10)
        if step == 'S':
            t.backward(10)
        if step == 'D':
            t.right(45)
        if step == 'A':
            t.left(45)
        if step == 'F':
            t.up()
        if step == 'G':
            t.down()

def append_symbol(symbol, instructions):
    f = open('custom_symbols.txt', 'a')
    f.write(symbol + ' ' + instructions + '\n')
    f.close()

def create_custom_symbols_dict():
    f = open('custom_symbols.txt', 'r')
    custom_symbols_dict = {}

    lines = f.readlines()
    for line in lines:
        line = line.strip().split(' ')
        custom_symbols_dict[str(line[0])] = str(line[1])

    f.close()
    return custom_symbols_dict

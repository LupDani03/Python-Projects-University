
def dot(t):
    t.up()
    t.forward(12)
    t.down()
    t.left(90)
    t.forward(3)
    t.right(90)
    t.forward(1)
    t.right(90)
    t.forward(3)
    t.left(90)
    t.forward(1)
    t.left(90)
    t.forward(4)


def question(t):
    t.up()
    t.forward(12)
    t.down()
    t.left(90)
    t.forward(3)
    t.right(90)
    t.forward(1)
    t.right(90)
    t.forward(3)
    t.left(90)
    t.forward(1)
    t.left(90)
    t.forward(4)
    t.up()
    t.forward(3)
    t.left(90)
    t.forward(1)
    t.right(90)
    t.down()
    t.forward(16)
    t.right(90)
    for i in range(20):
        t.left(10)
        t.forward(2)


def exclamation(t):
    t.up()
    t.forward(12)
    t.down()
    t.left(90)
    t.forward(3)
    t.right(90)
    t.forward(1)
    t.right(90)
    t.forward(3)
    t.left(90)
    t.forward(1)
    t.left(90)
    t.forward(4)
    t.up()
    t.forward(3)
    t.left(90)
    t.forward(2)
    t.right(90)
    t.down()
    t.forward(40)
    t.right(90)
    t.forward(1)
    t.right(90)
    t.forward(40)
    t.left(90)
    t.forward(1)
    t.left(90)
    t.forward(41)


def A(t):
    t.left(76)
    t.forward(51)
    t.right(152)
    t.forward(51)
    t.right(180)
    t.forward(25)
    t.left(76)
    t.forward(14)


def B(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(4)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(4)
    t.right(180)
    t.forward(4)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(7)


def C(t):
    t.up()
    t.forward(24)
    t.left(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(2)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(30)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(2)


def D(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    for i in range(18):
        t.forward(1)
        t.right(5)
    t.forward(23)
    for i in range(19):
        t.forward(1)
        t.right(5)


def E(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(23)
    t.up()
    t.right(90)
    t.forward(25)
    t.right(90)
    t.forward(23)
    t.right(180)
    t.down()
    t.forward(14)
    t.up()
    t.right(90)
    t.forward(21)
    t.right(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(23)


def F(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(23)
    t.up()
    t.right(90)
    t.forward(25)
    t.right(90)
    t.forward(23)
    t.right(180)
    t.down()
    t.forward(14)


def G(t):
    t.up()
    t.forward(24)
    t.left(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(2)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(30)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(2)
    t.up()
    t.forward(26)
    t.down()
    t.right(90)
    t.forward(10)
    t.up()
    t.forward(100)


def H(t):
    t.left(90)
    t.forward(46)
    t.right(180)
    t.forward(23)
    t.left(90)
    t.forward(23)
    t.left(90)
    t.forward(23)
    t.right(180)
    t.forward(46)


def I(t):
    t.up()
    t.forward(9)
    t.down()
    t.forward(7)
    t.right(180)
    t.forward(4)
    t.right(90)
    t.forward(46)
    t.right(90)
    t.forward(3)
    t.right(180)
    t.forward(7)


def J(t):
    t.up()
    t.forward(23)
    t.left(90)
    t.forward(46)
    t.right(180)
    t.down()
    t.forward(36)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(4)


def K(t):
    t.left(90)
    t.forward(46)
    t.right(180)
    t.forward(23)
    t.left(150)
    t.forward(27)
    t.right(180)
    t.forward(27)
    t.left(65)
    t.forward(28)


def L(t):
    t.left(90)
    t.forward(46)
    t.right(180)
    t.forward(46)
    t.left(90)
    t.forward(23)


def M(t):
    t.left(90)
    t.forward(46)
    t.right(145)
    t.forward(20)
    t.left(110)
    t.forward(20)
    t.right(145)
    t.forward(46)


def N(t):
    t.left(90)
    t.forward(46)
    t.right(153)
    t.forward(51)
    t.left(153)
    t.forward(46)


def O(t):
    t.up()
    t.forward(24)
    t.left(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(2)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(30)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(2)
    t.forward(26)


def P(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(4)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(4)
    t.right(180)
    t.forward(4)


def Q(t):
    t.up()
    t.forward(24)
    t.left(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(2)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(30)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(2)
    t.forward(26)
    t.left(30)
    t.forward(15)
    t.right(180)
    t.forward(30)


def R(t):
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(4)
    for i in range(36):
        t.forward(1)
        t.right(5)
    t.forward(4)
    t.right(180)
    t.forward(4)
    t.right(65)
    t.forward(28)


def S(t):
    t.up()
    t.left(90)
    t.forward(14)
    t.right(180)
    t.down()
    t.forward(2)
    for i in range(36):
        t.forward(1)
        t.left(5)
    t.left(38)
    t.forward(30)
    t.right(23)
    for i in range(38):
        t.forward(1)
        t.right(5)
    t.forward(2)


def T(t):
    t.up()
    t.forward(13)
    t.down()
    t.left(90)
    t.forward(46)
    t.right(90)
    t.forward(12)
    t.right(180)
    t.forward(23)


def U(t):
    t.up()
    t.left(90)
    t.forward(46)
    t.right(180)
    t.down()
    t.forward(35)
    for i in range(36):
        t.forward(1)
        t.left(5)
    t.forward(35)


def V(t):
    t.up()
    t.left(90)
    t.forward(46)
    t.right(180)
    t.down()
    t.left(16)
    t.forward(48)
    t.left(152)
    t.forward(48)


def W(t):
    t.up()
    t.left(90)
    t.forward(46)
    t.right(180)
    t.down()
    t.left(8)
    t.forward(46)
    t.left(161)
    t.forward(46)
    t.right(161)
    t.forward(46)
    t.left(161)
    t.forward(46)


def X(t):
    t.left(63)
    t.forward(51)
    t.left(117)
    t.up()
    t.forward(23)
    t.left(117)
    t.down()
    t.forward(51)


def Y(t):
    t.up()
    t.forward(13)
    t.left(90)
    t.down()
    t.forward(23)
    t.right(29)
    t.forward(26)
    t.right(180)
    t.forward(26)
    t.right(119)
    t.forward(26)


def Z(t):
    t.up()
    t.left(90)
    t.forward(46)
    t.right(90)
    t.down()
    t.forward(23)
    t.right(120)
    t.forward(51)
    t.left(120)
    t.forward(23)
    t.up()
    t.forward(100)


symb_dict = {
    '.': dot,
    '?': question,
    '!': exclamation,
    'A': A,
    'B': B,
    'C': C,
    'D': D,
    'E': E,
    'F': F,
    'G': G,
    'H': H,
    'I': I,
    'J': J,
    'K': K,
    'L': L,
    'M': M,
    'N': N,
    'O': O,
    'P': P,
    'Q': Q,
    'R': R,
    'S': S,
    'T': T,
    'U': U,
    'V': V,
    'W': W,
    'X': X,
    'Y': Y,
    'Z': Z
}
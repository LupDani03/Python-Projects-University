from ex_1.predef_symbols import symb_dict
from ex_1.symbols import recreate_symbol,create_custom_symbols_dict
import turtle

def verify_if_word_is_new(word):
    with open ('words.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line == word:
                return False
        return True

def define_word():
    word = input('Define a word: ')
    if verify_if_word_is_new(word) is False:
        print('This word has already been defined')
    if verify_if_word_is_new(word) is True:
        with open ('words.txt', 'a') as f:
            f.write(word + '\n')
            print('Word has been defined')

def draw_word():
    word = input('Draw a word: ')
    t = turtle.Turtle()
    width = turtle.screensize()[0]
    max_length = (width * 2 - 50) / 25
    position = -max_length // 2 * 25
    custom_symbols_dict = create_custom_symbols_dict()
    for c in word:
        if verify_if_word_is_new(word) is False:
            t.up()
            t.setposition(position, 0)
            t.down()
            if c in symb_dict:
                symb_dict[c](t)
            elif c in custom_symbols_dict:
                recreate_symbol(custom_symbols_dict[c], t)
            t.setheading(0)
            position += 30
        else:
            print('You have typed an undefined word')
            break
    if verify_if_word_is_new(word) is False:
        print('The word has been drawn, take a look in the Turtle Window, then click anywhere to continue')
        turtle.exitonclick()
    turtle.bye()




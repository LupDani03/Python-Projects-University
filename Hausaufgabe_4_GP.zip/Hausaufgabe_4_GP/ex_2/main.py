def afisare():
    pfad = input('Pfad zur Datei: ')
    word = input('Wort zu ersetzen: ')
    replacement = input('Ersatzwort: ')

    count = replace(pfad, word, replacement)

    print(f"Ersetzt '{word}' durch '{replacement}' an {count} Stelle(n)")


def replace(pfad, word, replacement):
    f = open(pfad, "rt")
    data = f.read()
    app = data.count(word)
    data = data.replace(word, replacement)
    f.close()
    f = open(pfad, "wt")
    f.write(data)
    return app


afisare()
class DataRepo:
    def __init__(self, file):
        self.file = file  # the file that contains all data files

    # saves a list of objects in file, each object on a different line
    def save(self, obj_list, obj_file):
        with open(f'{self.file}/{obj_file}', 'w') as f:
            for i, obj in enumerate(obj_list):
                f.write(str(obj))
                # prevents an empty line from being written at the end of the file
                if i < len(obj_list) - 1:
                    f.write('\n')

    # returns a list of objects from file
    def load(self, obj_file):
        with open(f'{self.file}/{obj_file}', 'r') as f:
            list_strings = f.read()
        return self.convert_from_str(list_strings)

    # returns a string that has the content of the file
    def read_file(self, obj_file):
        with open(f'{self.file}/{obj_file}', 'r') as f:
            string_file = f.read()
        return string_file

    # writes a string in the file
    def write_to_file(self, string_to_file, obj_file):
        with open(f'{self.file}/{obj_file}', 'w') as f:
            f.write(string_to_file)

    def convert_to_str(self, obj_list):
        pass

    def convert_from_str(self, obj_string):
        pass

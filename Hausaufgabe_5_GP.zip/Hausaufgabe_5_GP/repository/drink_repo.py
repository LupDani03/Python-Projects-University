from repository.data_repo import DataRepo
from modelle.drink import Drink


class DrinkRepo(DataRepo):
    def __init__(self, file):
        super().__init__(file)

    # transforms a list of objects in a list of strings
    def convert_to_str(self, obj_list):
        # transforms an object in a string
        def str_obj(obj):
            return f'Drink(id={obj.id}, name={obj.name}, portion_size={obj.portion_size}, price={obj.price}, alcohol_content={obj.alcohol_content})'

        return list(map(str_obj, obj_list))

    # transforms a string in a list of objects
    def convert_from_str(self, string_file):
        # transforms a string in an object
        def create_drink(element):
            # checks that there are no empty elements (if this type of item can't be ordered)
            if element:
                element = element[:-1]
                attributes = element.split(',')

                # extracts the values after the '='
                id = attributes[0].split('=')[1]
                name = attributes[1].split('=')[1]
                portion_size = attributes[2].split('=')[1]
                price = attributes[3].split('=')[1]
                alcohol_content = attributes[4].split('=')[1]

                return Drink(id, name, portion_size, price, alcohol_content)

        string_list = string_file.split('\n')
        return list(map(create_drink, string_list))

from modelle.client import Client
from modelle.cooked_dish import CookedDish
from modelle.drink import Drink
from modelle.order import Order


# reuturns index of 'item' in 'search_list'
def search_index(search_list, item):
    for i, obj in enumerate(search_list):
        if obj == item:
            return i


class Controller:
    def __init__(self, repo):
        self.repo = repo

    # adds new client
    def add_client(self, id, name, address):
        obj_list = self.repo.load('clients.txt')
        obj_list.append(Client(id, name, address))
        self.repo.save(self.repo.convert_to_str(obj_list), 'clients.txt')

    # adds new drink
    def add_drink(self, id, name, portion_size, price, alcohol_content):
        obj_list = self.repo.load('drinks.txt')
        obj_list.append(Drink(id, name, portion_size, price, alcohol_content))
        self.repo.save(self.repo.convert_to_str(obj_list), 'drinks.txt')

    # adds new dish
    def add_cooked_dish(self, id, name, portion_size, price, prep_time):
        obj_list = self.repo.load('cooked_dishes.txt')
        obj_list.append(CookedDish(id, name, portion_size, price, prep_time))
        self.repo.save(self.repo.convert_to_str(obj_list), 'cooked_dishes.txt')

    # edits client
    def edit_client(self, edit_id, new_name, new_address):
        # loads a list with existing clients in string format
        client_list = self.repo.convert_to_str(self.repo.load('clients.txt'))
        # adds clients with 'id == edi_id' in 'filtered_list'
        filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == edit_id, client_list))

        # if wanted client is found, data is edited
        if filtered_list:
            # client position is searched in 'client_list'
            index = search_index(client_list, filtered_list[0])
            # new data is replaced in list
            client_list[index] = f'Client(id={edit_id}, name={new_name}, address={new_address})'
            # changes are saved to file
            self.repo.save(client_list, 'clients.txt')
        else:  # if there is no client with 'id == edit_id'
            print(f'The client with the ID: {edit_id} does not exist')

    # edit a drink
    def edit_drink(self, edit_id):
        # load existing drinks in a list
        drinks_list = self.repo.convert_to_str(self.repo.load('drinks.txt'))
        # add searched objects in 'filtered_list'
        filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == edit_id, drinks_list))

        # if wanted drink is found, data is edited
        if filtered_list:
            # new data is read
            print('Enter new info:')
            new_name = input('New name = ')
            new_portion_size = input('New portion size = ')
            new_price = input('New price = ')
            new_alcohol_content = input('New alcohol content = ')

            # position of drink is searched in 'drinks_list'
            index = search_index(drinks_list, filtered_list[0])
            #  new data is replaced
            drinks_list[
                index] = f'Drink(id={edit_id}, name={new_name}, portion_size={new_portion_size}, price={new_price}, alcohool_content={new_alcohol_content})'
            # changes are saved
            self.repo.save(drinks_list, 'drinks.txt')
        else:  # if searched does not exist
            print(f'The drink with the ID: {edit_id} does not exist')

    # edit a dish
    def edit_cooked_dish(self, edit_id):
        # dishes are being loaded from a list of strings
        cooked_dishes_list = self.repo.convert_to_str(self.repo.load('cooked_dishes.txt'))
        # searched dish is added in a list
        filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == edit_id, cooked_dishes_list))

        # if searched food exists, data is edited
        if filtered_list:
            # new data is introduced
            print('Enter new info:')
            new_name = input('New name = ')
            new_portion_size = input('New portion size = ')
            new_price = input('New price = ')
            new_prep_time = input('New preparation time = ')

            # dish position is searched in 'cooked_dishes_list'
            index = search_index(cooked_dishes_list, filtered_list[0])
            # data is replaced
            cooked_dishes_list[
                index] = f'CookedDish(id={edit_id}, name={new_name}, portion_size={new_portion_size}, price={new_price}, prep_time={new_prep_time})'
            # info is saved
            self.repo.save(cooked_dishes_list, 'cooked_dishes.txt')
        else:  # if searched dish does not exist
            print(f'The cooked dish with the ID: {edit_id} does not exist')

    # remove a client/ a drink/ a dish
    def delete_entry(self, delete_id, file):
        # a list with the file elements is loaded
        entry_list = self.repo.convert_to_str(self.repo.load(file))
        # adds elements with 'id == edi_id' in 'filtered_list'
        filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == delete_id, entry_list))

        # if an element with 'id == delete_id' exists, then it is removed
        if filtered_list:
            entry_list.remove(filtered_list[0])
            self.repo.save(entry_list, file)
        else:  # if that element does not exist
            # transforms 'file' in the element type, so that it can be displayed
            item = file[:-6].replace("_", " ") if file == 'cooked_dishes.txt' else file[:-5]
            print(f'The {item} with the ID: {delete_id} does not exist')

    # returns an object that is of the 'order' type, and saves it in the file
    def generate_order(self, id, client_id, drinks_list, cooked_dishes_list, time_placed, expected_time):
        # creates object
        order = Order(id, client_id, drinks_list, cooked_dishes_list, time_placed, expected_time)
        # loads all orders in a list in string format
        order_list = self.repo.convert_to_str(self.repo.load('orders.txt'))
        # transforms the object in string and adds it in the list
        order_list.append(self.repo.convert_to_str([order])[0])
        # saves the list in file
        self.repo.save(order_list, 'orders.txt')
        return order

    # returns True/False if the product exists in files
    # item_type = '1' => drink  /  item_type = '2' => cooked_dish
    def search_item(self, id, item_type):
        if item_type == '1':
            drinks_list = self.repo.convert_to_str(self.repo.load('drinks.txt'))
            filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == id, drinks_list))
        else:
            cooked_dishes_list = self.repo.convert_to_str(self.repo.load('cooked_dishes.txt'))
            filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == id, cooked_dishes_list))
        return True if len(filtered_list) == 1 else False

    # returns id and nr_app
    # nr_app = number of clients that have in name/address 'client_info'
    # id = the id of the client / id = None if the client does not exist or if there are multiple clients
    def search_client_id(self, client_info):
        client_info = client_info.lower()
        # existent clients are loaded in the list
        client_list = self.repo.convert_to_str(self.repo.load('clients.txt'))

        # a new list is created with the clients that have 'client_info' in the name
        filtered_name_list = list(
            filter(lambda x: client_info in x.split('=')[2].split(',')[0].lower(), client_list))
        # a list is created with the clients that have 'client_info' in address
        filtered_address_list = list(
            filter(lambda x: client_info in x.split('=')[3].split(',')[0].lower(), client_list))
        # lists are united
        filtered_list = filtered_address_list + filtered_name_list

        # the clients that appear multiple times are removed('client_info' appears both in name and in address)
        rez = []
        for el in filtered_list:
            if el not in rez:
                rez.append(el)

        # if there are no clients with 'client_info'
        if len(rez) == 0:
            return None, 0

        # the final list is transformed in string and then in a list of objects
        rez = '\n'.join(rez)
        rez = self.repo.convert_from_str(rez)
        return (rez[0].id, 1) if len(rez) == 1 else (None, len(rez))

    def calculate_time(self, lista):
        # searches the object with the corresponding id and returns it
        def get_item(id):
            item_list = self.repo.convert_to_str(self.repo.load('cooked_dishes.txt'))
            filtered_list = list(filter(lambda x: x.split('=')[1].split(',')[0] == id, item_list))
            return self.repo.convert_from_str(filtered_list[0])[0]

        # sums up the minutes from 'prep_time'
        minutes = 0
        for id in lista:
            minutes += int(get_item(id).prep_time)

        # transforms minutes in hours and minutes
        hours = minutes // 60
        minutes = minutes % 60

        return hours, minutes

from ui.console import Console

app = Console()
app.main_menu()

class Identifiable:
    def __init__(self, id):
        self.id = id

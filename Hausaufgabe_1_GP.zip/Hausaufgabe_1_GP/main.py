# def prim(n):
#     if n == 0 or n == 1:
#         return False
#     for numar in range(2, n):
#         if n % numar == 0:
#             return False
#     return True
#
# def zehn_a():
#     n = input("Introdu n: ")
#     n = int(n)
#     for i in range(1, n-1):
#         for j in range(i, n):
#             if prim(i) and prim(j):
#                 if i+j == n:
#                     print(i, "+", j)
#
# zehn_a()

def diferit(a, b):
    cta = [0]*10
    ctb = [0]*10
    sem = 0
    a = int(a)
    b = int(b)
    print(a)
    print(b)
    while a != 0:
        cta[a % 10] = 1
        a //= 10
    while b != 0:
        ctb[b % 10] = 1
        b //= 10
    for i in range(0, 10):
            if cta[i] != ctb[i]:
                sem += 1
    return sem>=2

def zehn_b():
    lista = [123, 645, 353, 453, 905, 272, 494]
    rezultat = []
    temp = []
    for i in range(0, len(lista)-1):
        if diferit(lista[i], lista[i+1]):
            temp.append(lista[i])
        else:
            temp.append(lista[i])
            if len(temp) > len(rezultat):
                rezultat = temp
            temp = []
    if diferit(lista[-1],lista[-2]):
        temp.append(lista[-1])
    if len(temp) > len(rezultat):
        rezultat = temp
    print(rezultat)
    # pi = pf = 0
    # lcrt = lmax = 1
    # for i in range(0, len(lista)-1):
    #     if diferit(lista[i],lista[i+1]):
    #         lcrt += 1
    #     else:
    #         if lcrt > lmax:
    #             lmax = lcrt
    #             pf = i
    #             pi = i-lmax
    #         lcrt = 1
    # print("Lungimea maxima este : ", lmax)
    # print()
    # print("Secventa de lungime maxima este : ")
    # for i in range(pi, pf):
    #     print(lista[i], " ")

print(diferit(353,457))
zehn_b()